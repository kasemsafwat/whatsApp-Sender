# WhatsApp Bulk Message Sender - User Guide

## Overview
WhatsApp Bulk Message Sender is a desktop application that allows you to send WhatsApp messages to multiple recipients automatically. It's designed to save time when you need to send the same message to many different numbers.

## Installation
1. No installation is required - the application is portable
2. Make sure you have WhatsApp Desktop installed and logged in
3. Extract all files from the zip archive to a folder of your choice
4. Run `WhatsApp Sender.exe` from the `bin` folder

## System Requirements
- Windows 10 or later
- WhatsApp Desktop application installed and logged in
- Active internet connection
- Minimum 4GB RAM
- 100MB free disk space

## Getting Started
1. Launch the application by double-clicking `WhatsApp Sender.exe`
2. The main window will appear with the following sections:
   - Message input area (top)
   - Country code selector (middle)
   - Phone numbers input area (middle)
   - Number list (bottom)
   - Control buttons (bottom)

## Step-by-Step Usage
1. **Preparing Your Message**
   - Type or paste your message in the top text box
   - The message can include multiple lines and emojis
   - Format your message as desired - all formatting will be preserved

2. **Adding Phone Numbers**
   - Select the appropriate country code from the dropdown
   - Enter phone numbers in the input box (one per line)
   - Numbers can be entered with or without the country code
   - Click "Add Numbers" to add them to the list
   - You can add more numbers at any time

3. **Managing Numbers**
   - To remove a number, select it and click "Delete Selected"
   - To remove all numbers, click "Delete All"
   - You can add numbers in batches
   - Duplicate numbers will be automatically filtered out

4. **Sending Messages**
   - Review your message and number list
   - Click "Start Sending" to begin
   - The application will open WhatsApp
   - DO NOT use your keyboard or mouse while sending is in progress
   - Progress will be shown in the status bar
   - Wait for the "Success" message

## Tips and Best Practices
1. **Before Starting**
   - Make sure WhatsApp Desktop is installed and logged in
   - Close other applications to ensure smooth operation
   - Test with a small number of recipients first

2. **Number Format**
   - Numbers can be entered with or without country code
   - Remove any spaces or special characters
   - Examples of valid formats:
     - With country code: +966501234567
     - Without country code: 501234567

3. **During Sending**
   - Don't move the mouse or use keyboard
   - Keep WhatsApp window visible
   - Wait for each message to be sent
   - Watch the status bar for progress

## Troubleshooting
1. **Application Won't Start**
   - Make sure you're running as administrator
   - Check if WhatsApp Desktop is installed
   - Verify your internet connection

2. **Messages Not Sending**
   - Confirm WhatsApp Desktop is logged in
   - Check your internet connection
   - Verify the number format is correct
   - Make sure WhatsApp window is not minimized

3. **Common Error Messages**
   - "No valid country code": Add country code or select from dropdown
   - "Please enter a message": Message field is empty
   - "Please add at least one number": No numbers in the list

## Support
If you encounter any issues:
1. Check this user guide for solutions
2. Make sure you're using the latest version
3. Contact support with:
   - Description of the issue
   - Steps to reproduce
   - Screenshots if possible

## Updates
- Check for updates regularly
- Always backup your number lists before updating
- Download updates only from official sources

## Safety and Privacy
- The application does not store any messages or numbers
- All data is cleared when you close the application
- No data is sent to external servers
- Messages are sent directly through WhatsApp 