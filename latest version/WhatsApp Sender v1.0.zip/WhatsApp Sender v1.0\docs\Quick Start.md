# WhatsApp Bulk Message Sender - Quick Start Guide

## Quick Setup
1. Make sure WhatsApp Desktop is installed and logged in
2. Run `WhatsApp Sender.exe` from the `bin` folder

## Send Messages in 3 Steps

### 1. Prepare Your Message
- Type or paste your message in the top box
- Include emojis and formatting as needed

### 2. Add Numbers
- Select country code (Saudi Arabia 🇸🇦 or Egypt 🇪🇬)
- Enter phone numbers (one per line)
- Click "Add Numbers"

### 3. Send
- Click "Start Sending"
- Wait for completion
- Don't use keyboard or mouse while sending

## Need Help?
- See the full User Guide for detailed instructions
- Contact support if you have issues 